import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.examples.helloworld.GreeterGrpc;
import io.grpc.examples.helloworld.HelloReply;
import io.grpc.examples.helloworld.HelloRequest;

public class HelloWorldClient {
    public static void main(String[] args) {
        String host = "localhost";
        int port = 50051;

        // Cr�e un canal g�r� pour communiquer avec le serveur
        ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port)
                .usePlaintext() // Utilise une connexion non s�curis�e pour cet exemple
                .build();

        try {
            // Cr�e un stub Greeter avec le canal
            GreeterGrpc.GreeterBlockingStub blockingStub = GreeterGrpc.newBlockingStub(channel);

            // Remplacez ces valeurs par celles de l'utilisateur
            String prenom = "Ahmed";
            String nom = "Ben Ali";
            String cin = "1234567";

            // Construit la requ�te avec les informations de l'utilisateur
            HelloRequest request = HelloRequest.newBuilder()
                    .setPrenom(prenom)
                    .setNom(nom)
                    .setCin(cin)
                    .build();

            // Appelle la m�thode sayHello du serveur
            HelloReply response = blockingStub.sayHello(request);

            // Affiche la r�ponse du serveur
            System.out.println("R�ponse du serveur : " + response.getMessage());
        } catch (StatusRuntimeException e) {
            System.err.println("Erreur lors de l'appel au serveur : " + e.getStatus());
        } finally {
            // Ferme le canal
            channel.shutdown();
        }
    }
}
